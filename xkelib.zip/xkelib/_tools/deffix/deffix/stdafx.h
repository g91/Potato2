#pragma once

#include <SDKDDKVer.h>
#include <Windows.h>
#include <stdio.h>
#include <tchar.h>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

#include "types.h"
